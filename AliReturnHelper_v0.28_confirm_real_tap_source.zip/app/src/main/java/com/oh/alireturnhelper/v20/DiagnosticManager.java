package com.oh.alireturnhelper.v20;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityNodeInfo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public final class DiagnosticManager {
    private static final String DIR = "ali_return_diagnostics";
    private static final String SESSION_KEY = "diagnostic_session";
    private static final SimpleDateFormat FILE_TIME = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.KOREA);
    private static final SimpleDateFormat LOG_TIME = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.KOREA);

    private DiagnosticManager() {}

    public static synchronized File ensureSession(Context context) {
        SharedPreferences p = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        String name = p.getString(SESSION_KEY, "");
        File base = new File(context.getExternalFilesDir(null), DIR);
        if (!base.exists()) base.mkdirs();
        File session = name.isEmpty() ? null : new File(base, name);
        if (session == null || !session.exists()) {
            name = "session_" + FILE_TIME.format(new Date());
            session = new File(base, name);
            session.mkdirs();
            p.edit().putString(SESSION_KEY, name).apply();
            writeDeviceInfo(context, session);
        }
        return session;
    }

    public static synchronized File startNewSession(Context context) {
        context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                .edit().remove(SESSION_KEY).apply();
        return ensureSession(context);
    }

    public static synchronized void append(Context context, String message) {
        File session = ensureSession(context);
        File log = new File(session, "timeline.txt");
        try (FileWriter w = new FileWriter(log, true)) {
            w.write(LOG_TIME.format(new Date()) + "  " + message + "\n");
        } catch (IOException ignored) {}
    }

    public static synchronized File writeTree(Context context, AccessibilityNodeInfo root, String label) {
        File session = ensureSession(context);
        String safe = sanitize(label);
        File out = new File(session, FILE_TIME.format(new Date()) + "_tree_" + safe + ".txt");
        StringBuilder b = new StringBuilder();
        b.append("label=").append(label).append('\n');
        dumpNode(root, b, 0, 0);
        writeText(out, b.toString());
        return out;
    }

    private static int dumpNode(AccessibilityNodeInfo node, StringBuilder b, int depth, int count) {
        if (node == null || count > 2500) return count;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        for (int i = 0; i < depth; i++) b.append("  ");
        b.append(node.getClassName())
                .append(" text=").append(q(node.getText()))
                .append(" desc=").append(q(node.getContentDescription()))
                .append(" hint=").append(q(node.getHintText()))
                .append(" viewId=").append(q(node.getViewIdResourceName()))
                .append(" bounds=").append(r.toShortString())
                .append(" clickable=").append(node.isClickable())
                .append(" enabled=").append(node.isEnabled())
                .append(" visible=").append(node.isVisibleToUser())
                .append(" selected=").append(node.isSelected())
                .append(" checked=").append(node.isChecked())
                .append(" editable=").append(node.isEditable())
                .append('\n');
        count++;
        for (int i = 0; i < node.getChildCount(); i++) {
            count = dumpNode(node.getChild(i), b, depth + 1, count);
            if (count > 2500) break;
        }
        return count;
    }

    public static synchronized void writeState(Context context, String label) {
        SharedPreferences p = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        StringBuilder b = new StringBuilder();
        b.append("label=").append(label).append('\n');
        b.append("enabled=").append(p.getBoolean(MainActivity.KEY_ENABLED, false)).append('\n');
        b.append("armed=").append(p.getBoolean(MainActivity.KEY_ARMED, false)).append('\n');
        b.append("mode=").append(p.getString(MainActivity.KEY_MODE, "")).append('\n');
        b.append("step=").append(p.getInt(MainActivity.KEY_STEP, -1)).append('\n');
        b.append("phase=").append(p.getString(MainActivity.KEY_PHASE, "")).append('\n');
        b.append("retryTapCount=").append(p.getInt(MainActivity.KEY_RETRY_TAP_COUNT, 0)).append('\n');
        b.append("lastStatus=").append(p.getString(MainActivity.KEY_LAST_STATUS, "")).append('\n');
        b.append("autoSubmit=").append(p.getBoolean(MainActivity.KEY_AUTO_SUBMIT, false)).append('\n');
        b.append("recentLog=\n").append(p.getString(MainActivity.KEY_LOG, "")).append('\n');
        File out = new File(ensureSession(context), FILE_TIME.format(new Date()) + "_state_" + sanitize(label) + ".txt");
        writeText(out, b.toString());
    }

    public static File screenshotFile(Context context, String label) {
        return new File(ensureSession(context), FILE_TIME.format(new Date()) + "_screen_" + sanitize(label) + ".png");
    }

    public static synchronized File buildZip(Context context) throws IOException {
        File session = ensureSession(context);
        writeState(context, "export");
        File zip = new File(session.getParentFile(), session.getName() + "_diagnostic.zip");
        try (ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zip)))) {
            zipDirectory(session, session, zos);
        }
        return zip;
    }

    public static File currentSession(Context context) { return ensureSession(context); }

    private static void zipDirectory(File root, File file, ZipOutputStream zos) throws IOException {
        File[] files = file.listFiles();
        if (files == null) return;
        byte[] buf = new byte[8192];
        for (File child : files) {
            if (child.isDirectory()) { zipDirectory(root, child, zos); continue; }
            String name = root.toURI().relativize(child.toURI()).getPath();
            zos.putNextEntry(new ZipEntry(name));
            try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(child))) {
                int n; while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
            }
            zos.closeEntry();
        }
    }

    private static void writeDeviceInfo(Context context, File session) {
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        String text = "app=AliReturnHelper v0.28 reason confirm real tap\n"
                + "manufacturer=" + Build.MANUFACTURER + "\n"
                + "model=" + Build.MODEL + "\n"
                + "device=" + Build.DEVICE + "\n"
                + "android=" + Build.VERSION.RELEASE + "\n"
                + "sdk=" + Build.VERSION.SDK_INT + "\n"
                + "display=" + dm.widthPixels + "x" + dm.heightPixels + " density=" + dm.density + "\n"
                + "created=" + LOG_TIME.format(new Date()) + "\n";
        writeText(new File(session, "device_info.txt"), text);
    }

    private static void writeText(File file, String text) {
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(text.getBytes(StandardCharsets.UTF_8));
        } catch (IOException ignored) {}
    }

    private static String q(Object value) {
        if (value == null) return "\"\"";
        String s = String.valueOf(value).replace("\\", "\\\\").replace("\n", "\\n").replace("\"", "\\\"");
        if (s.length() > 250) s = s.substring(0, 250) + "…";
        return "\"" + s + "\"";
    }

    private static String sanitize(String s) {
        if (s == null || s.trim().isEmpty()) return "snapshot";
        return s.replaceAll("[^0-9A-Za-z가-힣._-]", "_");
    }
}
