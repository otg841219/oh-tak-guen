package com.oh.alireturnhelper.v20;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.graphics.Bitmap;
import android.graphics.ColorSpace;
import android.hardware.HardwareBuffer;
import android.view.Display;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import android.graphics.Path;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AliAccessibilityService extends AccessibilityService {
    private static final String ALI_PACKAGE = "com.alibaba.aliexpresshd";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastActionAt = 0L;
    private boolean actionPending = false;
    private long lastDiagnosticAt = 0L;
    private String lastDiagnosticLabel = "";

    private final Runnable poller = new Runnable() {
        @Override public void run() {
            try {
                SharedPreferences p = prefs();
                if (p.getBoolean(MainActivity.KEY_ARMED, false) && !actionPending
                        && System.currentTimeMillis() - lastActionAt >= 800) {
                    AccessibilityNodeInfo root = getRootInActiveWindow();
                    if (root != null && ALI_PACKAGE.equals(String.valueOf(root.getPackageName()))) {
                        runStateMachine(root, p);
                    }
                }
            } finally {
                handler.postDelayed(this, 1100);
            }
        }
    };

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        handler.removeCallbacks(poller);
        DiagnosticManager.append(this, "접근성 서비스 연결됨");
        DiagnosticManager.writeState(this, "service_connected");
        handler.postDelayed(poller, 700);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        if (!ALI_PACKAGE.contentEquals(event.getPackageName())) return;
        SharedPreferences p = prefs();
        if (!p.getBoolean(MainActivity.KEY_ARMED, false) || actionPending
                || System.currentTimeMillis() - lastActionAt < 700) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) runStateMachine(root, p);
    }

    private void runStateMachine(AccessibilityNodeInfo root, SharedPreferences p) {
        String mode = p.getString(MainActivity.KEY_MODE, MainActivity.MODE_CUSTOMS);
        boolean autoSubmit = p.getBoolean(MainActivity.KEY_AUTO_SUBMIT, false);
        int step = p.getInt(MainActivity.KEY_STEP, 0);
        String lastStatus = p.getString(MainActivity.KEY_LAST_STATUS, "");
        String phase = p.getString(MainActivity.KEY_PHASE, MainActivity.PHASE_NAVIGATE);

        String diagnosticLabel = "step_" + step + "_" + phase + "_" + lastStatus;
        boolean forceDiagnostic = MainActivity.PHASE_WAIT_RETRY_DETAIL.equals(phase)
                || containsText(root, "반품/환불 재신청")
                || containsByTraversal(root, "Re-apply for return/refund")
                || containsText(root, "마지막 해결책")
                || containsText(root, "주문 상품을 받으셨나요")
                || hasReceivedQuestionPopupByTraversal(root);
        captureDiagnostic(root, diagnosticLabel, forceDiagnostic);

        // 재신청 상세 진입은 일반 상태 문구가 아니라 별도 단계로 추적한다.
        // dispatchGesture()가 true를 반환해도 실제 웹뷰 버튼이 눌리지 않을 수 있으므로,
        // 화면이 "주문 상품을 받으셨나요?"로 바뀔 때까지 버튼 영역 여러 지점을 재시도한다.
        // AliExpress가 화면/접근성 언어를 섞어서 노출하는 경우가 있다.
        // 진단에서는 질문 문구 검색은 실패했지만 실제 Button 노드로 Yes/No/Close가 보였다.
        // 따라서 문구뿐 아니라 팝업의 Yes+No 버튼 조합도 수령 여부 팝업으로 판정한다.
        boolean receivedQuestion = containsText(root, "주문 상품을 받으셨나요")
                || containsText(root, "상품을 받으셨나요")
                || containsText(root, "Did you receive")
                || hasReceivedQuestionPopupByTraversal(root);
        boolean formAfterNo = containsText(root, "이유를 선택해 주세요")
                || containsText(root, "상품 선택")
                || containsText(root, "이 문제에 대해 자세히 알려주십시오");

        // '아니요'를 누른 직후에는 팝업이 먼저 사라지고 다음 폼이 늦게 뜨는 구간이 있다.
        // 이때 상세 화면의 '반품/환불 재신청'을 다시 누르면 팝업이 열렸다 닫히는 무한 루프가 된다.
        // 따라서 별도 대기 단계에서 실제 폼이 뜰 때까지 재신청 버튼을 절대 다시 누르지 않는다.
        if (MainActivity.PHASE_WAIT_AFTER_NO.equals(phase)) {
            if (formAfterNo) {
                p.edit().putString(MainActivity.KEY_PHASE, MainActivity.PHASE_FORM)
                        .putInt(MainActivity.KEY_RETRY_TAP_COUNT, 0)
                        .putLong(MainActivity.KEY_PHASE_STARTED_AT, System.currentTimeMillis())
                        .apply();
                phase = MainActivity.PHASE_FORM;
                addLog("아니요 선택 후 사유 입력 화면 확인 — 다음 단계 진행");
            } else if (receivedQuestion) {
                long startedAt = p.getLong(MainActivity.KEY_PHASE_STARTED_AT, 0L);
                if (System.currentTimeMillis() - startedAt >= 650L) {
                    retryNoButtonRealTap(root, p, step);
                } else {
                    handler.postDelayed(this::processCurrentWindow, 350);
                }
                return;
            } else {
                long startedAt = p.getLong(MainActivity.KEY_PHASE_STARTED_AT, 0L);
                long elapsed = System.currentTimeMillis() - startedAt;
                if (elapsed < 3500L) {
                    setStatus(step, "아니요 선택 후 다음 화면 로딩 대기 " + elapsed + "ms");
                    handler.postDelayed(this::processCurrentWindow, 450);
                    return;
                }
                // 3.5초 동안 다음 폼이 뜨지 않았을 때만 수령 팝업 단계를 다시 확인한다.
                p.edit().putString(MainActivity.KEY_PHASE, MainActivity.PHASE_WAIT_RECEIVED)
                        .putInt(MainActivity.KEY_RETRY_TAP_COUNT, 0)
                        .putLong(MainActivity.KEY_PHASE_STARTED_AT, System.currentTimeMillis())
                        .apply();
                phase = MainActivity.PHASE_WAIT_RECEIVED;
                addLog("아니요 이후 다음 폼 미확인 — 수령 팝업 상태를 다시 확인");
            }
        }

        if (receivedQuestion) {
            if (!MainActivity.PHASE_WAIT_RECEIVED.equals(phase)) {
                p.edit().putString(MainActivity.KEY_PHASE, MainActivity.PHASE_WAIT_RECEIVED)
                        .putInt(MainActivity.KEY_RETRY_TAP_COUNT, 0)
                        .putLong(MainActivity.KEY_PHASE_STARTED_AT, System.currentTimeMillis())
                        .apply();
                phase = MainActivity.PHASE_WAIT_RECEIVED;
                addLog("상품 수령 여부 팝업 감지 — 아니요 버튼 탐색 시작");
            }
            long startedAt = p.getLong(MainActivity.KEY_PHASE_STARTED_AT, 0L);
            if (System.currentTimeMillis() - startedAt >= 450L) {
                retryNoButton(root, p, step);
                return;
            }
        } else if (MainActivity.PHASE_WAIT_RECEIVED.equals(phase) && formAfterNo) {
            p.edit().putString(MainActivity.KEY_PHASE, MainActivity.PHASE_FORM)
                    .putInt(MainActivity.KEY_RETRY_TAP_COUNT, 0).apply();
            phase = MainActivity.PHASE_FORM;
            addLog("상품 미수령 선택 성공 — 사유 선택 화면 확인 중");
        }
        if (MainActivity.PHASE_WAIT_RETRY_DETAIL.equals(phase)) {
            long startedAt = p.getLong(MainActivity.KEY_PHASE_STARTED_AT, 0L);
            if (System.currentTimeMillis() - startedAt >= 700L) {
                // 일부 AliExpress WebView에서는 findAccessibilityNodeInfosByText()가 빈 결과를 주지만,
                // 진단 트리를 직접 순회하면 실제 Button 노드가 보인다. 따라서 수동 DFS로 먼저 찾는다.
                AccessibilityNodeInfo retryNode = findRetryButtonByTraversal(root);
                if (retryNode != null) {
                    Rect retryBounds = new Rect();
                    retryNode.getBoundsInScreen(retryBounds);
                    AccessibilityNodeInfo clickableRetry = findClickable(retryNode);
                    AccessibilityNodeInfo target = clickableRetry != null ? clickableRetry : retryNode;
                    int retryAttempt = p.getInt(MainActivity.KEY_RETRY_TAP_COUNT, 0);
                    addLog("재신청 버튼 DFS 발견 bounds=" + retryBounds.toShortString()
                            + " class=" + String.valueOf(retryNode.getClassName())
                            + " nodeClickable=" + retryNode.isClickable()
                            + " targetClickable=" + target.isClickable()
                            + " attempt=" + retryAttempt);

                    // 중요: WebView는 ACTION_CLICK이 true여도 실제 탭이 발생하지 않는 경우가 있다.
                    // 1회만 ACTION_CLICK을 시도하고, 화면이 그대로면 다음 폴링부터는
                    // 반드시 실제 버튼 bounds 안에 dispatchGesture 탭을 보낸다.
                    if (retryAttempt == 0) {
                        p.edit().putInt(MainActivity.KEY_RETRY_TAP_COUNT, 1)
                                .putLong(MainActivity.KEY_PHASE_STARTED_AT, System.currentTimeMillis()).apply();
                        boolean ok = target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                        lastActionAt = System.currentTimeMillis();
                        setStatus(step, ok
                                ? "재신청 ACTION_CLICK 1회 실행 — 0.9초 후 실제 화면 확인"
                                : "재신청 ACTION_CLICK 실패 — 실제 bounds 탭으로 전환");
                        handler.postDelayed(this::processCurrentWindow, ok ? 900 : 120);
                        return;
                    }

                    if (!retryBounds.isEmpty()) {
                        // ACTION_CLICK 이후에도 팝업이 없다는 뜻이므로 실제 터치 제스처를 사용한다.
                        clickRetryBoundsPattern(retryBounds, p, step);
                        return;
                    }

                    addLog("재신청 버튼 bounds가 비어 있음 — 3개 위치 탐색으로 전환");
                    retryRefundButtonArea(p, step);
                    return;
                }
                logVisibleButtons(root);
                addLog("재신청 버튼 DFS에서도 찾지 못해 3개 위치 좌표 탐색으로 전환");
                retryRefundButtonArea(p, step);
                return;
            }
        }

        // 진행 중 화면을 먼저 처리한다.
        if (containsExact(root, "주문 당시 결제 방식")) {
            AccessibilityNodeInfo payment = findExact(root, "주문 당시 결제 방식");
            AccessibilityNodeInfo clickable = findClickable(payment);
            if (clickable != null && !clickable.isChecked() && !clickable.isSelected()) {
                performDelayed(clickable, AccessibilityNodeInfo.ACTION_CLICK, null, step, "주문 당시 결제 방식 선택");
                return;
            }
            if (!autoSubmit) { finish("결제 방식 선택 완료 — 금액 확인 후 제출을 직접 누르세요."); return; }
            if (clickExactDelayed(root, "제출", step, "최종 제출")) return;
        }


        boolean reasonDialog = containsExact(root, "누락/잘못된 상품, 빈 택배")
                || containsExact(root, "상품 배송 실패") || containsExact(root, "세관에 보류됨");
        if (reasonDialog) {
            String reason = mode.equals(MainActivity.MODE_CUSTOMS) ? "세관에 보류됨" : "상품 배송 실패";
            AccessibilityNodeInfo reasonNode = findExact(root, reason);
            if (reasonNode != null && !reasonNode.isChecked() && !reasonNode.isSelected()) {
                AccessibilityNodeInfo clickable = findClickable(reasonNode);
                if (clickable != null) { performDelayed(clickable, AccessibilityNodeInfo.ACTION_CLICK, null, step, "사유 선택: " + reason); return; }
            }
            if (clickExactDelayed(root, "확인", step, "사유 확인")) return;
        }

        if (containsText(root, "이유를 선택해 주세요") || containsText(root, "이 문제에 대해 자세히 알려주십시오")) {
            if (containsExact(root, "선택 해주세요") || containsExact(root, "선택해주세요")) {
                if (clickFirstExactDelayed(root, new String[]{"선택 해주세요", "선택해주세요"}, step, "사유 목록 열기")) return;
            }
            if (mode.equals(MainActivity.MODE_RETURNED)) {
                AccessibilityNodeInfo editable = findBestEditable(root);
                if (editable != null && isEmpty(editable)) { setTextDelayed(editable, "반송됨", step, "상세 내용 입력: 반송됨"); return; }
            }
            AccessibilityNodeInfo unchecked = findFirstUncheckedCheckable(root);
            if (unchecked != null) { performDelayed(unchecked, AccessibilityNodeInfo.ACTION_CLICK, null, step, "추가 상품 선택"); return; }
            if (clickExactDelayed(root, "다음", step, "다음 단계")) return;
        }

        // 재신청 상세 화면 처리. 알리 버전에 따라 버튼 문구가 접근성 트리에
        // 정확히 노출되지 않거나 영어 화면 제목과 한국어 본문이 섞여 표시될 수 있다.
        AccessibilityNodeInfo retry = MainActivity.PHASE_NAVIGATE.equals(phase)
                ? findContainsAny(root, new String[]{"반품/환불 재신청", "환불 재신청", "재신청"})
                : null;
        if (retry != null) {
            AccessibilityNodeInfo clickable = findClickable(retry);
            if (clickable != null) {
                p.edit().putString(MainActivity.KEY_PHASE, MainActivity.PHASE_FORM).apply();
                performDelayed(clickable, AccessibilityNodeInfo.ACTION_CLICK, null, step,
                        "반품/환불 재신청 열기");
                return;
            }
            addLog("재신청 문구 노드는 찾았지만 클릭 불가 — 버튼 중앙 좌표 시도");
            clickNodeCenterDelayed(retry, step, "반품/환불 재신청 좌표 클릭");
            return;
        }

        // 버튼 문구가 접근성 트리에서 완전히 빠지는 경우의 화면 기반 보조 클릭.
        // '요청 완료', '마지막 해결책: 환불 불가', '사용자 증거 가이드라인'이 함께
        // 보이면 사용자가 보여준 재신청 상세 화면으로 판단한다.
        boolean retryDetailScreen = containsText(root, "마지막 해결책")
                && containsText(root, "환불 불가")
                && (containsText(root, "사용자 증거 가이드라인")
                    || containsText(root, "자료: 택배 정보"));
        if (retryDetailScreen) {
            addLog("재신청 버튼 문구 미노출 — 상세 화면 비율 좌표 클릭 시도");
            clickNormalizedDelayed(root, 0.25f, 0.515f, step,
                    "반품/환불 재신청 비율 좌표 클릭");
            return;
        }

        if (containsExact(root, "요청 완료")) {
            AccessibilityNodeInfo request = findBestRequestComplete(root);
            if (request != null) {
                AccessibilityNodeInfo row = findRequestRowClickable(request);
                if (row != null) {
                    markWaitingForRetryDetail(p);
                    performDelayed(row, AccessibilityNodeInfo.ACTION_CLICK, null, step, "요청 완료 줄 클릭");
                    return;
                }
                markWaitingForRetryDetail(p);
                clickNodeCenterDelayed(request, step, "요청 완료 글자 좌표 클릭");
                return;
            }
            addLog("요청 완료 문구는 보이지만 클릭 대상을 찾지 못함");
        }

        // 주문목록까지 자동 이동.
        // 중요: 계정 화면에서는 하단의 "계정" 탭이 계속 보이므로, 먼저 "모두 보기"를 처리해야 한다.
        boolean accountScreen = containsText(root, "내 주문")
                && (containsText(root, "결제 대기") || containsText(root, "배송 예정")
                || containsText(root, "배송 중") || containsText(root, "반품"));

        if (accountScreen) {
            if (clickFirstExactDelayed(root,
                    new String[]{"모두 보기", "전체 보기", "View all"},
                    step, "주문 모두 보기")) return;

            // 일부 알리 버전은 '모두 보기'가 접근성에서 클릭 불가로 노출된다.
            // 그때는 주문 상태 아무 항목으로 목록에 진입한다.
            if (clickFirstExactDelayed(root,
                    new String[]{"결제 대기", "배송 예정", "배송 중", "반품"},
                    step, "주문 목록 우회 진입")) return;
        }

        // 계정 화면이 아닐 때만 하단 계정 탭을 누른다. 반복 클릭 루프 방지.
        if (!accountScreen && clickFirstExactDelayed(root,
                new String[]{"계정", "Account"}, step, "계정 탭 열기")) return;

        // 다른 형태의 내 주문 진입 버튼 대응.
        if (!accountScreen && clickFirstExactDelayed(root,
                new String[]{"내 주문", "My orders"}, step, "내 주문 열기")) return;

        // 주문목록에서는 반드시 "전체" 탭만 누른다.
        // "처리 완료"는 주문이 없을 수 있으므로 절대 자동 선택하지 않는다.
        if (isOrdersTabScreen(root) && !isAllTabSelected(root)) {
            AccessibilityNodeInfo allTab = findTabNode(root, "전체");
            AccessibilityNodeInfo clickable = findClickable(allTab);
            if (clickable != null) {
                performDelayed(clickable, AccessibilityNodeInfo.ACTION_CLICK, null, step, "전체 주문 탭 선택");
                return;
            }
            if (allTab != null) {
                clickNodeCenterDelayed(allTab, step, "전체 주문 탭 좌표 선택");
                return;
            }
        }

        // 주문목록이 아래에 더 있으면 한 번씩 내려서 요청 완료를 찾는다.
        if (containsText(root, "주문") || containsText(root, "환불 완료") || containsText(root, "배송 완료")) {
            if (root.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) {
                lastActionAt = System.currentTimeMillis();
                setStatus(step, "주문목록에서 요청 완료 검색 중");
                return;
            }
        }

        if (containsText(root, "신청이 접수") || containsText(root, "요청이 제출") || containsText(root, "환불 요청 검토")) {
            finish("재신청 접수 완료");
        }
    }

    private void processCurrentWindow() {
        if (actionPending) return;
        SharedPreferences p = prefs();
        if (!p.getBoolean(MainActivity.KEY_ARMED, false)) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            addLog("현재 화면 접근성 트리 없음 — 다음 폴링에서 재시도");
            return;
        }
        CharSequence packageName = root.getPackageName();
        if (packageName == null || !ALI_PACKAGE.contentEquals(packageName)) {
            addLog("알리익스프레스 화면이 아님 — 현재 패키지=" + packageName);
            return;
        }
        runStateMachine(root, p);
    }

    private boolean isOrdersTabScreen(AccessibilityNodeInfo root) {
        return containsText(root, "결제대기중") || containsText(root, "결제 대기")
                || containsText(root, "처리 중") || containsText(root, "처리 완료")
                || containsText(root, "배송됨");
    }

    private boolean isAllTabSelected(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo node = findTabNode(root, "전체");
        if (node == null) return false;
        if (node.isSelected() || node.isChecked()) return true;
        AccessibilityNodeInfo current = node;
        for (int i = 0; current != null && i < 4; i++, current = current.getParent()) {
            if (current.isSelected() || current.isChecked()) return true;
        }
        return false;
    }

    private AccessibilityNodeInfo findTabNode(AccessibilityNodeInfo root, String text) {
        if (root == null) return null;
        List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByText(text);
        if (list == null) return null;
        AccessibilityNodeInfo best = null;
        int bestTop = Integer.MAX_VALUE;
        for (AccessibilityNodeInfo node : list) {
            if (!node.isVisibleToUser()) continue;
            String value = node.getText() == null ? "" : node.getText().toString().trim();
            String desc = node.getContentDescription() == null ? "" : node.getContentDescription().toString().trim();
            if (!text.equals(value) && !text.equals(desc)) continue;
            Rect r = new Rect();
            node.getBoundsInScreen(r);
            // 상단 주문 상태 탭만 선택한다. 상품 본문에 같은 글자가 있어도 제외.
            if (r.top >= 0 && r.top < 450 && r.left < 220 && r.width() > 0) {
                if (r.top < bestTop) { best = node; bestTop = r.top; }
            }
        }
        return best;
    }

    private void clickNodeCenterDelayed(AccessibilityNodeInfo node, int step, String status) {
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        addLog(status + " 위치=" + r.toShortString());
        final float x = r.centerX();
        final float y = r.centerY();
        actionPending = true;
        handler.postDelayed(() -> {
            try {
                Path path = new Path();
                path.moveTo(x, y);
                boolean ok = dispatchGesture(new GestureDescription.Builder()
                        .addStroke(new GestureDescription.StrokeDescription(path, 0, 80))
                        .build(), null, null);
                if (ok) {
                    lastActionAt = System.currentTimeMillis();
                    setStatus(step + 1, status);
                } else {
                    setStatus(step, "누르기 실패: " + status);
                }
            } finally { actionPending = false; }
        }, 500);
    }

    private AccessibilityNodeInfo findBestRequestComplete(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> all = root.findAccessibilityNodeInfosByText("요청 완료");
        if (all == null) return null;
        AccessibilityNodeInfo best = null;
        int bestTop = Integer.MAX_VALUE;
        for (AccessibilityNodeInfo node : all) {
            if (!isExact(node, "요청 완료") || !node.isVisibleToUser()) continue;
            Rect r = new Rect();
            node.getBoundsInScreen(r);
            // 상단 탭이나 안내문이 아니라 주문 카드 안의 실제 요청 완료 줄만 선택.
            if (r.top < 350 || r.width() <= 0 || r.height() <= 0) continue;
            if (r.top < bestTop) { best = node; bestTop = r.top; }
        }
        return best;
    }

    private AccessibilityNodeInfo findRequestRowClickable(AccessibilityNodeInfo request) {
        if (request == null) return null;
        Rect requestBounds = new Rect();
        request.getBoundsInScreen(requestBounds);
        AccessibilityNodeInfo current = request;
        AccessibilityNodeInfo fallback = null;
        for (int i = 0; current != null && i < 7; i++, current = current.getParent()) {
            Rect r = new Rect();
            current.getBoundsInScreen(r);
            // 요청 완료와 같은 가로 줄 정도만 허용. 주문 카드 전체까지 올라가지 않게 제한한다.
            boolean sameRow = r.top <= requestBounds.top + 45
                    && r.bottom >= requestBounds.bottom - 45
                    && r.height() < 220;
            if (sameRow && current.isClickable() && current.isEnabled() && current.isVisibleToUser()) {
                return current;
            }
            if (sameRow && fallback == null) fallback = current;
        }
        // 오른쪽 화살표가 별도 노드인 경우 같은 행에서 클릭 가능한 형제를 탐색.
        AccessibilityNodeInfo parent = request.getParent();
        for (int depth = 0; parent != null && depth < 4; depth++, parent = parent.getParent()) {
            AccessibilityNodeInfo found = findClickableInSameRow(parent, requestBounds);
            if (found != null) return found;
        }
        return fallback != null && fallback.isClickable() ? fallback : null;
    }

    private AccessibilityNodeInfo findClickableInSameRow(AccessibilityNodeInfo node, Rect target) {
        if (node == null) return null;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        boolean overlapsRow = r.bottom >= target.top - 35 && r.top <= target.bottom + 35;
        if (overlapsRow && node.isClickable() && node.isEnabled() && node.isVisibleToUser()
                && r.height() < 220) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo found = findClickableInSameRow(node.getChild(i), target);
            if (found != null) return found;
        }
        return null;
    }


    private AccessibilityNodeInfo findRetryButtonByTraversal(AccessibilityNodeInfo node) {
        if (node == null) return null;
        String text = node.getText() == null ? "" : node.getText().toString().replace("\n", " ").trim();
        String desc = node.getContentDescription() == null ? "" : node.getContentDescription().toString().replace("\n", " ").trim();
        String merged = text + " " + desc;
        String lower = merged.toLowerCase(java.util.Locale.ROOT);
        boolean matches = merged.contains("반품/환불 재신청")
                || merged.contains("환불 재신청")
                || (merged.contains("재신청") && !merged.contains("이의"))
                || lower.contains("re-apply for return/refund")
                || lower.contains("reapply for return/refund")
                || (lower.contains("re-apply") && lower.contains("refund"));
        if (matches && node.isVisibleToUser() && node.isEnabled()) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo found = findRetryButtonByTraversal(child);
            if (found != null) return found;
        }
        return null;
    }


    // findAccessibilityNodeInfosByText()가 WebView에서 누락되는 경우를 대비한 직접 DFS 검사.
    private boolean containsByTraversal(AccessibilityNodeInfo node, String needle) {
        if (node == null || needle == null) return false;
        String text = node.getText() == null ? "" : node.getText().toString();
        String desc = node.getContentDescription() == null ? "" : node.getContentDescription().toString();
        String lowerNeedle = needle.toLowerCase(java.util.Locale.ROOT);
        if ((text + " " + desc).toLowerCase(java.util.Locale.ROOT).contains(lowerNeedle)
                && node.isVisibleToUser()) return true;
        for (int i = 0; i < node.getChildCount(); i++) {
            if (containsByTraversal(node.getChild(i), needle)) return true;
        }
        return false;
    }

    private boolean hasReceivedQuestionPopupByTraversal(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo yes = findButtonByTraversal(root, new String[]{"Yes", "예"});
        AccessibilityNodeInfo no = findButtonByTraversal(root, new String[]{"No", "아니요", "아니오"});
        if (yes == null || no == null) return false;
        Rect y = new Rect();
        Rect n = new Rect();
        yes.getBoundsInScreen(y);
        no.getBoundsInScreen(n);
        boolean sameRow = Math.abs(y.centerY() - n.centerY()) <= 160;
        boolean usable = yes.isVisibleToUser() && no.isVisibleToUser() && sameRow;
        if (usable) {
            addLog("상품 수령 팝업 버튼 조합 감지 Yes=" + y.toShortString()
                    + " No=" + n.toShortString());
        }
        return usable;
    }

    private AccessibilityNodeInfo findButtonByTraversal(AccessibilityNodeInfo node, String[] labels) {
        if (node == null) return null;
        String text = node.getText() == null ? "" : node.getText().toString().trim();
        String desc = node.getContentDescription() == null ? "" : node.getContentDescription().toString().trim();
        CharSequence cls = node.getClassName();
        boolean buttonLike = node.isClickable() || (cls != null && cls.toString().contains("Button"));
        if (node.isVisibleToUser() && buttonLike) {
            for (String label : labels) {
                if (text.equalsIgnoreCase(label) || desc.equalsIgnoreCase(label)) return node;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo found = findButtonByTraversal(node.getChild(i), labels);
            if (found != null) return found;
        }
        return null;
    }

    private void logVisibleButtons(AccessibilityNodeInfo node) {
        if (node == null) return;
        CharSequence cls = node.getClassName();
        if (node.isVisibleToUser() && cls != null && cls.toString().contains("Button")) {
            Rect r = new Rect();
            node.getBoundsInScreen(r);
            addLog("보이는 버튼: text=" + String.valueOf(node.getText())
                    + " desc=" + String.valueOf(node.getContentDescription())
                    + " bounds=" + r.toShortString() + " clickable=" + node.isClickable());
        }
        for (int i = 0; i < node.getChildCount(); i++) logVisibleButtons(node.getChild(i));
    }

    private void clickRetryBoundsPattern(Rect bounds, SharedPreferences p, int step) {
        int count = p.getInt(MainActivity.KEY_RETRY_TAP_COUNT, 0);
        float[][] ratios = new float[][]{
                {0.50f, 0.50f}, {0.35f, 0.50f}, {0.65f, 0.50f},
                {0.50f, 0.35f}, {0.50f, 0.65f}
        };
        int idx = Math.min(count, ratios.length - 1);
        p.edit().putInt(MainActivity.KEY_RETRY_TAP_COUNT, count + 1).apply();
        float x = bounds.left + bounds.width() * ratios[idx][0];
        float y = bounds.top + bounds.height() * ratios[idx][1];
        clickAbsoluteDelayed(x, y, step,
                "재신청 실제 bounds 내부 클릭 " + (idx + 1) + "/" + ratios.length,
                () -> handler.postDelayed(this::processCurrentWindow, 850));
    }

    private AccessibilityNodeInfo findContainsAny(AccessibilityNodeInfo root, String[] needles) {
        if (root == null || needles == null) return null;
        for (String needle : needles) {
            List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByText(needle);
            if (list == null) continue;
            for (AccessibilityNodeInfo node : list) {
                if (node == null || !node.isVisibleToUser()) continue;
                String text = node.getText() == null ? "" : node.getText().toString().trim();
                String desc = node.getContentDescription() == null ? "" : node.getContentDescription().toString().trim();
                if (text.contains(needle) || desc.contains(needle)) return node;
            }
        }
        return null;
    }

    private void markWaitingForRetryDetail(SharedPreferences p) {
        p.edit().putString(MainActivity.KEY_PHASE, MainActivity.PHASE_WAIT_RETRY_DETAIL)
                .putInt(MainActivity.KEY_RETRY_TAP_COUNT, 0)
                .putLong(MainActivity.KEY_PHASE_STARTED_AT, System.currentTimeMillis())
                .apply();
        addLog("재신청 상세 화면 전환 대기 시작");
    }

    private void retryNoButton(AccessibilityNodeInfo root, SharedPreferences p, int step) {
        int count = p.getInt(MainActivity.KEY_RETRY_TAP_COUNT, 0);
        final int maxAttempts = 15;
        if (count >= maxAttempts) {
            p.edit().putBoolean(MainActivity.KEY_ARMED, false).apply();
            setStatus(step, "아니요 버튼 15회 탐색 실패 — 진단 ZIP을 보내 주세요");
            captureDiagnostic(root, "no_button_failed", true);
            return;
        }

        AccessibilityNodeInfo noNode = findButtonByTraversal(root,
                new String[]{"아니요", "아니오", "No", "NO"});
        if (noNode == null) {
            noNode = findContainsAny(root, new String[]{"아니요", "아니오", "No", "NO"});
        }
        if (noNode != null) {
            Rect bounds = new Rect();
            noNode.getBoundsInScreen(bounds);
            addLog("아니요 노드 감지 bounds=" + bounds.toShortString()
                    + " clickable=" + noNode.isClickable());
            AccessibilityNodeInfo clickable = findClickable(noNode);
            p.edit().putInt(MainActivity.KEY_RETRY_TAP_COUNT, count + 1).apply();
            if (clickable != null) {
                // 클릭 성공/실패 반환값만 믿지 않고, 먼저 '아니요 이후 대기' 단계로 잠근다.
                p.edit().putString(MainActivity.KEY_PHASE, MainActivity.PHASE_WAIT_AFTER_NO)
                        .putInt(MainActivity.KEY_RETRY_TAP_COUNT, 0)
                        .putLong(MainActivity.KEY_PHASE_STARTED_AT, System.currentTimeMillis())
                        .apply();
                actionPending = true;
                handler.postDelayed(() -> {
                    boolean ok = clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    actionPending = false;
                    lastActionAt = System.currentTimeMillis();
                    setStatus(step, ok
                            ? "아니요 ACTION_CLICK 1회 실행 — 실제 다음 화면 확인 중"
                            : "아니요 ACTION_CLICK 실패 — 실제 버튼 bounds 탭으로 전환");
                    handler.postDelayed(this::processCurrentWindow, ok ? 850 : 120);
                }, 180);
                return;
            }
            if (!bounds.isEmpty()) {
                p.edit().putString(MainActivity.KEY_PHASE, MainActivity.PHASE_WAIT_AFTER_NO)
                        .putInt(MainActivity.KEY_RETRY_TAP_COUNT, 0)
                        .putLong(MainActivity.KEY_PHASE_STARTED_AT, System.currentTimeMillis()).apply();
                clickAbsoluteDelayed(bounds.centerX(), bounds.centerY(), step,
                        "아니요 노드 중앙 실제 탭",
                        () -> handler.postDelayed(this::processCurrentWindow, 850));
                return;
            }
        }

        final float[][] points = new float[][]{
                {0.27f, 0.548f}, {0.20f, 0.548f}, {0.34f, 0.548f},
                {0.27f, 0.575f}, {0.20f, 0.575f}, {0.34f, 0.575f},
                {0.27f, 0.520f}, {0.20f, 0.520f}, {0.34f, 0.520f},
                {0.27f, 0.605f}, {0.20f, 0.605f}, {0.34f, 0.605f},
                {0.15f, 0.560f}, {0.40f, 0.560f}, {0.27f, 0.630f}
        };
        float[] point = points[Math.min(count, points.length - 1)];
        p.edit().putInt(MainActivity.KEY_RETRY_TAP_COUNT, count + 1).apply();
        clickDisplayRatioDelayed(point[0], point[1], step,
                "아니요 좌표 탐색 " + (count + 1) + "/" + maxAttempts);
    }

    private void retryNoButtonRealTap(AccessibilityNodeInfo root, SharedPreferences p, int step) {
        int count = p.getInt(MainActivity.KEY_RETRY_TAP_COUNT, 0);
        if (count >= 6) {
            p.edit().putBoolean(MainActivity.KEY_ARMED, false).apply();
            setStatus(step, "아니요 실제 탭 6회 후에도 팝업 유지 — 진단 ZIP을 보내 주세요");
            captureDiagnostic(root, "no_real_tap_failed", true);
            return;
        }
        AccessibilityNodeInfo noNode = findButtonByTraversal(root, new String[]{"아니요", "아니오", "No", "NO"});
        if (noNode == null) noNode = findContainsAny(root, new String[]{"아니요", "아니오", "No", "NO"});
        if (noNode == null) {
            setStatus(step, "아니요 팝업은 보이지만 버튼 노드 미검출 — 재확인");
            handler.postDelayed(this::processCurrentWindow, 400);
            return;
        }
        Rect b = new Rect();
        noNode.getBoundsInScreen(b);
        if (b.isEmpty()) {
            setStatus(step, "아니요 버튼 bounds 비어 있음 — 재확인");
            handler.postDelayed(this::processCurrentWindow, 400);
            return;
        }
        final float[][] offsets = new float[][]{
                {0.50f,0.50f},{0.35f,0.50f},{0.65f,0.50f},
                {0.50f,0.35f},{0.50f,0.65f},{0.25f,0.50f}
        };
        float[] o = offsets[Math.min(count, offsets.length - 1)];
        float x = b.left + b.width() * o[0];
        float y = b.top + b.height() * o[1];
        p.edit().putInt(MainActivity.KEY_RETRY_TAP_COUNT, count + 1)
                .putLong(MainActivity.KEY_PHASE_STARTED_AT, System.currentTimeMillis()).apply();
        addLog("아니요 실제 bounds 탭 " + (count + 1) + "/6 bounds=" + b.toShortString());
        clickAbsoluteDelayed(x, y, step,
                "아니요 실제 bounds 탭 " + (count + 1) + "/6",
                () -> handler.postDelayed(this::processCurrentWindow, 900));
    }

    private void retryRefundButtonArea(SharedPreferences p, int step) {
        AccessibilityNodeInfo diagnosticRoot = getRootInActiveWindow();
        if (diagnosticRoot != null) captureDiagnostic(diagnosticRoot, "before_retry_button_tap_" + p.getInt(MainActivity.KEY_RETRY_TAP_COUNT, 0), true);
        // 알리 상세 화면은 안내문 길이에 따라 재신청 버튼이 2~3개 높이 중 하나에 나타난다.
        // 절대 좌표 한 구간만 고집하지 않고 화면 높이 비율 기준의 세 밴드를 순환한다.
        // 각 밴드에서 왼쪽 버튼 내부의 여러 x 지점을 눌러 실제 화면 전환 여부를 확인한다.
        final float[][] points = new float[][]{
                // 위치 A: 안내문이 짧은 화면
                {0.25f, 0.338f}, {0.18f, 0.338f}, {0.32f, 0.338f},
                {0.25f, 0.355f}, {0.14f, 0.346f}, {0.40f, 0.346f},
                // 위치 B: 중간 길이 화면
                {0.25f, 0.410f}, {0.18f, 0.410f}, {0.32f, 0.410f},
                {0.25f, 0.430f}, {0.14f, 0.420f}, {0.40f, 0.420f},
                // 위치 C: 안내문이 긴 화면
                {0.25f, 0.485f}, {0.18f, 0.485f}, {0.32f, 0.485f},
                {0.25f, 0.505f}, {0.14f, 0.495f}, {0.40f, 0.495f}
        };
        int attempt = p.getInt(MainActivity.KEY_RETRY_TAP_COUNT, 0);
        if (attempt >= points.length) {
            setStatus(step, "재신청 버튼 3개 위치 탐색 실패 — 진단 ZIP을 보내 주세요");
            p.edit().putBoolean(MainActivity.KEY_ARMED, false).apply();
            return;
        }
        float[] point = points[attempt];
        int nextAttempt = attempt + 1;
        p.edit().putInt(MainActivity.KEY_RETRY_TAP_COUNT, nextAttempt)
                .putLong(MainActivity.KEY_PHASE_STARTED_AT, System.currentTimeMillis())
                .apply();
        int band = attempt < 6 ? 1 : (attempt < 12 ? 2 : 3);
        clickDisplayRatioDelayed(point[0], point[1], step,
                "반품/환불 재신청 위치" + band + " 탐색 " + nextAttempt + "/" + points.length);
    }

    private void clickAbsoluteDelayed(float x, float y, int step, String status, Runnable after) {
        android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        final float safeX = Math.max(1f, Math.min(x, metrics.widthPixels - 1f));
        final float safeY = Math.max(1f, Math.min(y, metrics.heightPixels - 1f));
        addLog(status + " 절대좌표=(" + Math.round(safeX) + "," + Math.round(safeY)
                + ") 화면=" + metrics.widthPixels + "x" + metrics.heightPixels);
        actionPending = true;
        handler.postDelayed(() -> {
            try {
                Path path = new Path();
                path.moveTo(safeX, safeY);
                boolean ok = dispatchGesture(new GestureDescription.Builder()
                        .addStroke(new GestureDescription.StrokeDescription(path, 0, 90))
                        .build(), new GestureResultCallback() {
                            @Override public void onCompleted(GestureDescription gestureDescription) {
                                lastActionAt = System.currentTimeMillis();
                                setStatus(step, status + " 제스처 완료 — 화면 전환 확인 중");
                                actionPending = false;
                                if (after != null) after.run();
                            }
                            @Override public void onCancelled(GestureDescription gestureDescription) {
                                setStatus(step, "제스처 취소: " + status);
                                actionPending = false;
                                if (after != null) after.run();
                            }
                        }, null);
                if (!ok) {
                    setStatus(step, "제스처 접수 실패: " + status);
                    actionPending = false;
                    if (after != null) after.run();
                }
            } catch (Throwable t) {
                setStatus(step, "제스처 예외: " + t.getClass().getSimpleName() + " / " + status);
                actionPending = false;
                if (after != null) after.run();
            }
        }, 180);
    }

    private void clickDisplayRatioDelayed(float xRatio, float yRatio,
                                          int step, String status) {
        android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        final float x = Math.max(1f, Math.min(metrics.widthPixels * xRatio, metrics.widthPixels - 1f));
        final float y = Math.max(1f, Math.min(metrics.heightPixels * yRatio, metrics.heightPixels - 1f));
        addLog(status + " 비율좌표=(" + xRatio + "," + yRatio + ") 실제=("
                + Math.round(x) + "," + Math.round(y) + ") 화면="
                + metrics.widthPixels + "x" + metrics.heightPixels);
        actionPending = true;
        handler.postDelayed(() -> {
            try {
                Path path = new Path();
                path.moveTo(x, y);
                boolean ok = dispatchGesture(new GestureDescription.Builder()
                        .addStroke(new GestureDescription.StrokeDescription(path, 0, 80))
                        .build(), new GestureResultCallback() {
                            @Override public void onCompleted(GestureDescription gestureDescription) {
                                lastActionAt = System.currentTimeMillis();
                                setStatus(step, status + " 제스처 완료 — 화면 전환 확인 중");
                                actionPending = false;
                                handler.postDelayed(AliAccessibilityService.this::processCurrentWindow, 850);
                            }
                            @Override public void onCancelled(GestureDescription gestureDescription) {
                                addLog(status + " 제스처 취소");
                                actionPending = false;
                                handler.postDelayed(AliAccessibilityService.this::processCurrentWindow, 450);
                            }
                        }, null);
                if (!ok) {
                    addLog(status + " 제스처 접수 실패");
                    actionPending = false;
                    handler.postDelayed(AliAccessibilityService.this::processCurrentWindow, 450);
                }
            } catch (Throwable t) {
                addLog(status + " 예외=" + t.getClass().getSimpleName() + ":" + t.getMessage());
                actionPending = false;
                handler.postDelayed(AliAccessibilityService.this::processCurrentWindow, 450);
            }
        }, 250);
    }

    private void clickDisplayXRatioAbsoluteYDelayed(float xRatio, float absoluteY,
                                                     int step, String status) {
        android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        final float x = metrics.widthPixels * xRatio;
        final float y = Math.max(1f, Math.min(absoluteY, metrics.heightPixels - 1f));
        addLog(status + " 교정좌표=(" + Math.round(x) + "," + Math.round(y)
                + ") 화면=" + metrics.widthPixels + "x" + metrics.heightPixels
                + " [진단근거 버튼 y≈745~840]");
        actionPending = true;
        handler.postDelayed(() -> {
            try {
                Path path = new Path();
                path.moveTo(x, y);
                boolean ok = dispatchGesture(new GestureDescription.Builder()
                        .addStroke(new GestureDescription.StrokeDescription(path, 0, 80))
                        .build(), new GestureResultCallback() {
                            @Override public void onCompleted(GestureDescription gestureDescription) {
                                lastActionAt = System.currentTimeMillis();
                                setStatus(step, status + " 제스처 완료 — 화면 전환 확인 중");
                                actionPending = false;
                            }
                            @Override public void onCancelled(GestureDescription gestureDescription) {
                                setStatus(step, "제스처 취소: " + status);
                                actionPending = false;
                            }
                        }, null);
                if (!ok) {
                    setStatus(step, "제스처 등록 실패: " + status);
                    actionPending = false;
                }
            } catch (Exception e) {
                setStatus(step, "제스처 예외: " + e.getClass().getSimpleName() + " / " + status);
                actionPending = false;
            }
        }, 250);
    }



    private void clickNormalizedDelayed(AccessibilityNodeInfo root, float xRatio, float yRatio,
                                        int step, String status) {
        Rect screen = new Rect();
        root.getBoundsInScreen(screen);
        if (screen.width() <= 0 || screen.height() <= 0) {
            setStatus(step, "화면 좌표 계산 실패: " + status);
            return;
        }
        final float x = screen.left + screen.width() * xRatio;
        final float y = screen.top + screen.height() * yRatio;
        addLog(status + " 좌표=(" + Math.round(x) + "," + Math.round(y) + ") 화면=" + screen.toShortString());
        actionPending = true;
        handler.postDelayed(() -> {
            try {
                Path path = new Path();
                path.moveTo(x, y);
                boolean ok = dispatchGesture(new GestureDescription.Builder()
                        .addStroke(new GestureDescription.StrokeDescription(path, 0, 100))
                        .build(), null, null);
                if (ok) {
                    lastActionAt = System.currentTimeMillis();
                    setStatus(step + 1, status);
                } else {
                    setStatus(step, "누르기 실패: " + status);
                }
            } finally {
                actionPending = false;
            }
        }, 550);
    }

    private boolean clickExactDelayed(AccessibilityNodeInfo root, String text, int step, String status) {
        AccessibilityNodeInfo node = findExact(root, text); AccessibilityNodeInfo clickable = findClickable(node);
        if (clickable == null) return false;
        performDelayed(clickable, AccessibilityNodeInfo.ACTION_CLICK, null, step, status); return true;
    }
    private boolean clickFirstExactDelayed(AccessibilityNodeInfo root, String[] texts, int step, String status) {
        for (String text : texts) if (clickExactDelayed(root, text, step, status)) return true; return false;
    }
    private void setTextDelayed(AccessibilityNodeInfo node, String text, int step, String status) {
        Bundle args = new Bundle(); args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        performDelayed(node, AccessibilityNodeInfo.ACTION_SET_TEXT, args, step, status);
    }
    private void performDelayed(AccessibilityNodeInfo node, int action, Bundle args, int step, String status) {
        actionPending = true;
        handler.postDelayed(() -> {
            try {
                boolean ok = args == null ? node.performAction(action) : node.performAction(action, args);
                if (ok) { lastActionAt = System.currentTimeMillis(); setStatus(step + 1, status); }
                else setStatus(step, "누르기 실패: " + status);
            } finally { actionPending = false; }
        }, 750);
    }
    private AccessibilityNodeInfo findExact(AccessibilityNodeInfo root, String text) {
        if (root == null) return null; List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByText(text); if (list == null) return null;
        for (AccessibilityNodeInfo node : list) if (isExact(node, text) && node.isVisibleToUser()) return node; return null;
    }
    private boolean containsExact(AccessibilityNodeInfo root, String text) { return findExact(root, text) != null; }
    private boolean isExact(AccessibilityNodeInfo node, String text) {
        if (node == null) return false; CharSequence t = node.getText(); CharSequence d = node.getContentDescription();
        return (t != null && text.equals(t.toString().trim())) || (d != null && text.equals(d.toString().trim()));
    }
    private boolean containsText(AccessibilityNodeInfo root, String text) {
        if (root == null) return false; List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByText(text); return list != null && !list.isEmpty();
    }
    private AccessibilityNodeInfo findClickable(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        for (int i = 0; current != null && i < 8; i++) { if (current.isClickable() && current.isEnabled() && current.isVisibleToUser()) return current; current = current.getParent(); }
        return null;
    }
    private AccessibilityNodeInfo findBestEditable(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> out = new ArrayList<>(); collectEditables(root, out); AccessibilityNodeInfo fallback = null;
        for (AccessibilityNodeInfo node : out) { String hint = node.getHintText() == null ? "" : node.getHintText().toString(); if (hint.contains("자세") || hint.contains("세부") || hint.contains("정보")) return node; if (fallback == null) fallback = node; }
        return fallback;
    }
    private void collectEditables(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out) {
        if (node == null) return; if (node.isEditable() && node.isEnabled() && node.isVisibleToUser()) out.add(node);
        for (int i = 0; i < node.getChildCount(); i++) collectEditables(node.getChild(i), out);
    }
    private AccessibilityNodeInfo findFirstUncheckedCheckable(AccessibilityNodeInfo node) {
        if (node == null) return null; if (node.isCheckable() && !node.isChecked() && node.isEnabled() && node.isVisibleToUser()) return node;
        for (int i = 0; i < node.getChildCount(); i++) { AccessibilityNodeInfo found = findFirstUncheckedCheckable(node.getChild(i)); if (found != null) return found; }
        return null;
    }
    private boolean isEmpty(AccessibilityNodeInfo node) { CharSequence text = node.getText(); return text == null || text.toString().trim().isEmpty(); }
    private SharedPreferences prefs() { return getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE); }
    private void setStatus(int step, String status) {
        prefs().edit().putInt(MainActivity.KEY_STEP, step)
                .putString(MainActivity.KEY_LAST_STATUS, status).apply();
        addLog(status);
        DiagnosticManager.writeState(this, status);
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) captureDiagnostic(root, status, status.contains("실패") || status.contains("재시도") || status.contains("재신청"));
        if (status.contains("진단 ZIP을 보내 주세요") || status.contains("탐색 실패")) {
            PcDiagnosticUploader.autoUploadIfEnabled(this, status);
        }
    }

    private void addLog(String message) {
        SharedPreferences p = prefs();
        String old = p.getString(MainActivity.KEY_LOG, "");
        String time = new SimpleDateFormat("HH:mm:ss", Locale.KOREA).format(new Date());
        String line = time + "  " + message;
        String combined = old.isEmpty() ? line : old + "\n" + line;
        String[] lines = combined.split("\n");
        if (lines.length > 30) {
            StringBuilder b = new StringBuilder();
            for (int i = lines.length - 30; i < lines.length; i++) {
                if (b.length() > 0) b.append('\n');
                b.append(lines[i]);
            }
            combined = b.toString();
        }
        p.edit().putString(MainActivity.KEY_LOG, combined).apply();
        DiagnosticManager.append(this, message);
    }

    private void finish(String status) {
        prefs().edit().putBoolean(MainActivity.KEY_ARMED, false)
                .putString(MainActivity.KEY_LAST_STATUS, status).apply();
        addLog(status);
        DiagnosticManager.writeState(this, "finish_" + status);
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) captureDiagnostic(root, "finish_" + status, true);
        PcDiagnosticUploader.autoUploadIfEnabled(this, status);
        Toast.makeText(this, status, Toast.LENGTH_LONG).show();
    }

    private void captureDiagnostic(AccessibilityNodeInfo root, String label, boolean force) {
        long now = System.currentTimeMillis();
        String safeLabel = label == null ? "snapshot" : label;
        if (!force && now - lastDiagnosticAt < 2500L && safeLabel.equals(lastDiagnosticLabel)) return;
        if (!force && now - lastDiagnosticAt < 1400L) return;
        lastDiagnosticAt = now;
        lastDiagnosticLabel = safeLabel;
        DiagnosticManager.writeTree(this, root, safeLabel);
        DiagnosticManager.writeState(this, safeLabel);
        requestScreenshot(safeLabel);
    }

    private void requestScreenshot(String label) {
        if (android.os.Build.VERSION.SDK_INT < 30) {
            DiagnosticManager.append(this, "화면 캡처 미지원: Android 11 이상 필요");
            return;
        }
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult screenshot) {
                    HardwareBuffer buffer = screenshot.getHardwareBuffer();
                    ColorSpace colorSpace = screenshot.getColorSpace();
                    Bitmap wrapped = Bitmap.wrapHardwareBuffer(buffer, colorSpace);
                    if (wrapped == null) {
                        buffer.close();
                        DiagnosticManager.append(AliAccessibilityService.this, "화면 캡처 변환 실패: " + label);
                        return;
                    }
                    Bitmap copy = wrapped.copy(Bitmap.Config.ARGB_8888, false);
                    buffer.close();
                    File out = DiagnosticManager.screenshotFile(AliAccessibilityService.this, label);
                    try (FileOutputStream stream = new FileOutputStream(out)) {
                        copy.compress(Bitmap.CompressFormat.PNG, 92, stream);
                        DiagnosticManager.append(AliAccessibilityService.this, "화면 캡처 저장: " + out.getName());
                    } catch (IOException e) {
                        DiagnosticManager.append(AliAccessibilityService.this, "화면 캡처 저장 실패: " + e.getMessage());
                    } finally {
                        copy.recycle();
                    }
                }

                @Override public void onFailure(int errorCode) {
                    DiagnosticManager.append(AliAccessibilityService.this, "화면 캡처 실패 코드=" + errorCode + " label=" + label);
                }
            });
        } catch (Exception e) {
            DiagnosticManager.append(this, "화면 캡처 예외: " + e.getClass().getSimpleName() + " " + e.getMessage());
        }
    }

    @Override public void onInterrupt() { }
    @Override public void onDestroy() { handler.removeCallbacks(poller); super.onDestroy(); }
}
