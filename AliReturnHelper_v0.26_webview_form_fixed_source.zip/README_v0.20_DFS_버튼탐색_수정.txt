알리 반품 도우미 v0.20 수정 내용

진단 ZIP 분석 결과:
- 접근성 트리에는 '반품/환불 재신청' 버튼이 android.widget.Button, clickable=true로 존재했습니다.
- 그러나 AliExpress WebView에서 findAccessibilityNodeInfosByText()가 빈 결과를 반환해 프로그램이 버튼을 못 찾았습니다.
- 좌표 제스처는 일부 화면에서 실제 버튼을 눌러도 화면 전환을 만들지 못했습니다.

수정:
1. 접근성 트리를 직접 DFS 순회해 버튼을 찾습니다.
2. 발견한 실제 Button 노드에 같은 프레임에서 즉시 ACTION_CLICK을 실행합니다.
3. ACTION_CLICK 실패 시 진단 트리의 실제 bounds 내부 5개 지점을 순서대로 누릅니다.
4. 버튼을 못 찾으면 화면에 보이는 모든 Button의 문구/좌표/clickable 상태를 로그에 남깁니다.
5. 로그/스크린샷/접근성 트리/진단 ZIP 기능을 유지합니다.
