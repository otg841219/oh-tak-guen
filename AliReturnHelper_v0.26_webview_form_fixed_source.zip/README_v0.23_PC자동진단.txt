알리 반품 도우미 v0.23 - PC 자동 진단 전송

1. PC_receiver 폴더의 START_RECEIVER.bat 실행
2. 창에 표시된 IPv4 주소 확인 (예: 192.168.0.19)
3. 휴대폰 앱의 PC IP 칸에 입력, 포트 8766
4. PC 연결 테스트 -> 성공 확인
5. '자동화 종료/중요 실패 시 ... 자동 전송' 체크

전송된 ZIP 저장 위치:
C:\AliReturnDiagnostics\

중요:
- 휴대폰과 PC는 같은 Wi-Fi여야 합니다.
- Windows 방화벽에서 차단되면 PC_receiver\ALLOW_FIREWALL_ADMIN.bat를 관리자 권한으로 실행합니다.
- 수신 프로그램 창을 닫으면 자동전송이 되지 않습니다.
