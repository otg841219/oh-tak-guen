알리 반품 도우미 v0.20 진단형

이 버전은 자동화 실패 원인을 한 번에 확인할 수 있도록 아래 자료를 자동 저장합니다.

1. timeline.txt: 시간별 전체 동작 로그
2. *_screen_*.png: 자동화 단계별 실제 화면 캡처
3. *_tree_*.txt: 알리 화면의 접근성 노드 구조(문구, 좌표, 클릭 가능 여부)
4. *_state_*.txt: 자동화 단계, 모드, 재시도 횟수, 마지막 상태
5. device_info.txt: 휴대폰 모델, 안드로이드 버전, 화면 해상도

빌드
1. Android Studio에서 이 v16diag 폴더 자체를 엽니다.
2. Build → Clean Project
3. Build → Generate App Bundles or APKs → Generate APKs
4. app/build/outputs/apk/debug/app-debug.apk를 설치합니다.

사용
1. 접근성에서 '알리 반품 자동화 서비스 v0.20'를 사용 중으로 켭니다.
2. 앱에서 사유 버튼을 눌러 자동화를 실행합니다.
3. 실패하거나 멈추면 앱으로 돌아옵니다.
4. '진단 ZIP 한 번에 보내기'를 누릅니다.
5. 생성된 ZIP 하나만 ChatGPT에 첨부하면 됩니다.

주의
- 진단 ZIP에는 주문번호, 화면 문구 등 개인정보가 포함될 수 있습니다.
- 자동 제출은 처음에는 끈 상태로 시험하세요.
