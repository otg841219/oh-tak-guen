알리 반품 도우미 v0.20.1 빌드 오류 수정

수정 내용
1. clickDisplayRatioDelayed(...) 중복 선언 제거
2. 제스처 완료 후 현재 화면을 다시 검사하는 processCurrentWindow() 추가
3. v0.20의 3개 버튼 위치 탐색, 로그·스크린샷·진단 ZIP 기능 유지

빌드:
Build > Clean Project
Build > Generate App Bundles or APKs > Generate APKs
