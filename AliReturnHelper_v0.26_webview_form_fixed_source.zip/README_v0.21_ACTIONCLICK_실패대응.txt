AliReturnHelper v0.21

진단 session_20260807_115246_270 분석 결과:
- 실제 재신청 Button 노드는 정상 발견됨: bounds=[126,744][456,840], clickable=true
- 하지만 ACTION_CLICK이 true를 반환해도 화면이 전혀 바뀌지 않음
- v0.20은 이 상태에서 매 폴링마다 ACTION_CLICK만 반복해 실제 dispatchGesture fallback으로 내려가지 못했음

v0.21 수정:
1. 재신청 버튼에 ACTION_CLICK은 딱 1회만 실행
2. 0.9초 뒤에도 '주문 상품을 받으셨나요?' 팝업이 없으면 ACTION_CLICK 성공 여부와 무관하게 실제 버튼 bounds 내부를 dispatchGesture로 탭
3. bounds 내부 여러 지점을 순차 재시도
4. 화면 전환이 실제 확인될 때만 다음 단계 진행
5. 기존 전체 진단 ZIP/스크린샷/접근성 트리/로그 유지
