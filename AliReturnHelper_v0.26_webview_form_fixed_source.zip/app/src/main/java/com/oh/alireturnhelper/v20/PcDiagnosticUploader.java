package com.oh.alireturnhelper.v20;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;

public final class PcDiagnosticUploader {
    public static final String KEY_PC_AUTO_UPLOAD = "pc_auto_upload";
    public static final String KEY_PC_HOST = "pc_host";
    public static final String KEY_PC_PORT = "pc_port";
    public static final String KEY_PC_LAST_RESULT = "pc_last_result";
    private static final AtomicBoolean uploading = new AtomicBoolean(false);

    public interface Callback { void onDone(boolean ok, String message); }
    private PcDiagnosticUploader() {}

    public static void testAsync(Context context, Callback callback) {
        new Thread(() -> {
            boolean ok = false;
            String msg;
            try {
                SharedPreferences p = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
                String host = p.getString(KEY_PC_HOST, "").trim();
                int port = parsePort(p.getString(KEY_PC_PORT, "8766"));
                if (host.isEmpty()) throw new Exception("PC IP가 비어 있습니다.");
                HttpURLConnection c = (HttpURLConnection) new URL("http://" + host + ":" + port + "/ping").openConnection();
                c.setConnectTimeout(3500); c.setReadTimeout(3500); c.setRequestMethod("GET");
                int code = c.getResponseCode();
                String body = readSmall(code >= 200 && code < 400 ? c.getInputStream() : c.getErrorStream());
                ok = code == 200;
                msg = ok ? "PC 연결 성공: " + host + ":" + port : "PC 연결 실패 HTTP " + code + " " + body;
                c.disconnect();
            } catch (Exception e) { msg = "PC 연결 실패: " + e.getMessage(); }
            saveResult(context, msg);
            deliver(callback, ok, msg);
        }, "ali-pc-test").start();
    }

    public static void uploadNowAsync(Context context, String reason, Callback callback) {
        if (!uploading.compareAndSet(false, true)) {
            deliver(callback, false, "이미 진단파일을 PC로 보내는 중입니다."); return;
        }
        new Thread(() -> {
            boolean ok = false; String msg;
            try {
                SharedPreferences p = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
                String host = p.getString(KEY_PC_HOST, "").trim();
                int port = parsePort(p.getString(KEY_PC_PORT, "8766"));
                if (host.isEmpty()) throw new Exception("PC IP가 비어 있습니다.");
                File zip = DiagnosticManager.buildZip(context);
                String qReason = URLEncoder.encode(reason == null ? "manual" : reason, "UTF-8");
                HttpURLConnection c = (HttpURLConnection) new URL("http://" + host + ":" + port + "/upload?reason=" + qReason).openConnection();
                c.setConnectTimeout(5000); c.setReadTimeout(30000); c.setDoOutput(true); c.setRequestMethod("POST");
                c.setRequestProperty("Content-Type", "application/zip");
                c.setRequestProperty("X-Filename", zip.getName());
                c.setFixedLengthStreamingMode(zip.length());
                try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(zip));
                     BufferedOutputStream out = new BufferedOutputStream(c.getOutputStream())) {
                    byte[] buf = new byte[64 * 1024]; int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    out.flush();
                }
                int code = c.getResponseCode();
                String body = readSmall(code >= 200 && code < 400 ? c.getInputStream() : c.getErrorStream());
                ok = code == 200;
                msg = ok ? "PC 자동전송 성공: " + zip.getName() : "PC 자동전송 실패 HTTP " + code + " " + body;
                c.disconnect();
                DiagnosticManager.append(context, msg);
            } catch (Exception e) {
                msg = "PC 자동전송 실패: " + e.getClass().getSimpleName() + " " + e.getMessage();
                DiagnosticManager.append(context, msg);
            } finally { uploading.set(false); }
            saveResult(context, msg);
            deliver(callback, ok, msg);
        }, "ali-pc-upload").start();
    }

    public static void autoUploadIfEnabled(Context context, String reason) {
        SharedPreferences p = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        if (!p.getBoolean(KEY_PC_AUTO_UPLOAD, false)) return;
        if (p.getString(KEY_PC_HOST, "").trim().isEmpty()) return;
        uploadNowAsync(context.getApplicationContext(), reason, null);
    }

    private static int parsePort(String s) {
        try { int p = Integer.parseInt(s.trim()); return (p > 0 && p <= 65535) ? p : 8766; }
        catch (Exception e) { return 8766; }
    }
    private static String readSmall(InputStream in) {
        if (in == null) return "";
        try { byte[] b = new byte[1024]; int n = in.read(b); return n <= 0 ? "" : new String(b, 0, n, StandardCharsets.UTF_8); }
        catch (Exception e) { return ""; }
        finally { try { in.close(); } catch (Exception ignored) {} }
    }
    private static void saveResult(Context c, String msg) {
        c.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE).edit().putString(KEY_PC_LAST_RESULT, msg).apply();
    }
    private static void deliver(Callback cb, boolean ok, String msg) {
        if (cb == null) return;
        new Handler(Looper.getMainLooper()).post(() -> cb.onDone(ok, msg));
    }
}
