알리 반품 도우미 v0.20

진단 ZIP 분석 결과:
- 반품/환불 재신청 버튼은 접근성 트리에 android.widget.Button, clickable=true, bounds=[126,744][456,840]로 정상 노출됨.
- 이전 버전은 WAIT_RETRY_DETAIL 단계에서 좌표 클릭 후 바로 return하여 실제 버튼 노드 ACTION_CLICK 코드가 실행되지 않았음.

v0.20 수정:
1. 재신청 상세 단계에서 버튼 노드를 우선 검색
2. clickable 부모/자체에 ACTION_CLICK 실행
3. ACTION_CLICK 반환 실패 시 해당 노드 bounds 중앙 좌표 클릭
4. 노드 자체가 없을 때만 3개 위치 좌표 탐색
5. 로그에 bounds와 clickable 여부 기록
