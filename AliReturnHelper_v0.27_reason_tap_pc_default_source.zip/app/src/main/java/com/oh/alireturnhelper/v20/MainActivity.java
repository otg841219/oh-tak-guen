package com.oh.alireturnhelper.v20;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;

public class MainActivity extends Activity {
    public static final String PREFS = "ali_return_prefs";
    public static final String KEY_ENABLED = "automation_enabled";
    public static final String KEY_ARMED = "armed";
    public static final String KEY_MODE = "mode";
    public static final String KEY_STEP = "step";
    public static final String KEY_AUTO_SUBMIT = "auto_submit";
    public static final String KEY_LAST_STATUS = "last_status";
    public static final String KEY_LOG = "action_log";
    public static final String KEY_PHASE = "phase";
    public static final String KEY_RETRY_TAP_COUNT = "retry_tap_count";
    public static final String KEY_PHASE_STARTED_AT = "phase_started_at";
    public static final String KEY_REASON_TAP_COUNT = "reason_tap_count";
    public static final String PHASE_NAVIGATE = "navigate";
    public static final String PHASE_WAIT_RETRY_DETAIL = "wait_retry_detail";
    public static final String PHASE_FORM = "form";
    public static final String PHASE_WAIT_RECEIVED = "wait_received";
    public static final String PHASE_WAIT_AFTER_NO = "wait_after_no";

    public static final String MODE_CUSTOMS = "customs";
    public static final String MODE_RETURNED = "returned";

    private CheckBox autoSubmitCheck;
    private TextView statusText;
    private TextView logText;
    private TextView diagnosticPathText;
    private EditText pcHostEdit;
    private EditText pcPortEdit;
    private CheckBox pcAutoUploadCheck;
    private TextView pcTransferStatusText;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        autoSubmitCheck = findViewById(R.id.autoSubmitCheck);
        statusText = findViewById(R.id.statusText);
        logText = findViewById(R.id.logText);
        diagnosticPathText = findViewById(R.id.diagnosticPathText);
        pcHostEdit = findViewById(R.id.pcHostEdit);
        pcPortEdit = findViewById(R.id.pcPortEdit);
        pcAutoUploadCheck = findViewById(R.id.pcAutoUploadCheck);
        pcTransferStatusText = findViewById(R.id.pcTransferStatusText);
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        autoSubmitCheck.setChecked(p.getBoolean(KEY_AUTO_SUBMIT, false));
        // 앱을 다시 설치해도 이 PC 수신기로 바로 진단파일을 보낼 수 있게 기본값을 저장한다.
        String savedHost = p.getString(PcDiagnosticUploader.KEY_PC_HOST, "").trim();
        if (savedHost.isEmpty()) {
            savedHost = PcDiagnosticUploader.DEFAULT_PC_HOST;
            p.edit().putString(PcDiagnosticUploader.KEY_PC_HOST, savedHost)
                    .putString(PcDiagnosticUploader.KEY_PC_PORT, "8766")
                    .putBoolean(PcDiagnosticUploader.KEY_PC_AUTO_UPLOAD, true).apply();
        }
        pcHostEdit.setText(savedHost);
        pcPortEdit.setText(p.getString(PcDiagnosticUploader.KEY_PC_PORT, "8766"));
        pcAutoUploadCheck.setChecked(p.getBoolean(PcDiagnosticUploader.KEY_PC_AUTO_UPLOAD, true));

        findViewById(R.id.accessibilityButton).setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        findViewById(R.id.openAliButton).setOnClickListener(v -> openAliExpress());
        findViewById(R.id.customsButton).setOnClickListener(v -> startAutomation(MODE_CUSTOMS));
        findViewById(R.id.returnedButton).setOnClickListener(v -> startAutomation(MODE_RETURNED));
        findViewById(R.id.stopButton).setOnClickListener(v -> stopAutomation("사용자가 중지함"));
        findViewById(R.id.copyLogButton).setOnClickListener(v -> copyLogs());
        findViewById(R.id.shareDiagnosticButton).setOnClickListener(v -> shareDiagnosticZip());
        findViewById(R.id.newDiagnosticButton).setOnClickListener(v -> {
            File dir = DiagnosticManager.startNewSession(this);
            Toast.makeText(this, "새 진단 기록을 시작했습니다.", Toast.LENGTH_SHORT).show();
            diagnosticPathText.setText("진단 저장 위치: " + dir.getAbsolutePath());
        });
        findViewById(R.id.savePcButton).setOnClickListener(v -> savePcSettings(true));
        findViewById(R.id.testPcButton).setOnClickListener(v -> {
            savePcSettings(false);
            pcTransferStatusText.setText("PC 연결 테스트 중...");
            PcDiagnosticUploader.testAsync(this, (ok, msg) -> {
                pcTransferStatusText.setText(msg);
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
            });
        });
        findViewById(R.id.sendPcNowButton).setOnClickListener(v -> {
            savePcSettings(false);
            pcTransferStatusText.setText("진단 ZIP을 PC로 보내는 중...");
            PcDiagnosticUploader.uploadNowAsync(this, "manual", (ok, msg) -> {
                pcTransferStatusText.setText(msg);
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
            });
        });
        findViewById(R.id.clearLogButton).setOnClickListener(v -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_LOG).apply();
            refreshStatus();
        });
        DiagnosticManager.ensureSession(this);
    }

    @Override protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void refreshStatus() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        statusText.setText("상태: " + p.getString(KEY_LAST_STATUS, "대기 중"));
        String log = p.getString(KEY_LOG, "");
        logText.setText(log.isEmpty() ? "아직 로그가 없습니다." : log);
        diagnosticPathText.setText("진단 저장 위치: " + DiagnosticManager.currentSession(this).getAbsolutePath());
        pcTransferStatusText.setText(getSharedPreferences(PREFS, MODE_PRIVATE)
                .getString(PcDiagnosticUploader.KEY_PC_LAST_RESULT, "PC 자동전송: 설정 대기"));
    }

    private void savePcSettings(boolean toast) {
        String host = pcHostEdit.getText().toString().trim();
        String port = pcPortEdit.getText().toString().trim();
        if (port.isEmpty()) port = "8766";
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(PcDiagnosticUploader.KEY_PC_HOST, host)
                .putString(PcDiagnosticUploader.KEY_PC_PORT, port)
                .putBoolean(PcDiagnosticUploader.KEY_PC_AUTO_UPLOAD, pcAutoUploadCheck.isChecked())
                .apply();
        if (toast) Toast.makeText(this, "PC 자동전송 설정을 저장했습니다.", Toast.LENGTH_SHORT).show();
    }

    private void copyLogs() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String log = p.getString(KEY_LOG, "");
        String status = p.getString(KEY_LAST_STATUS, "대기 중");
        String text = "상태: " + status + (log.isEmpty() ? "" : "\n" + log);
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("알리 반품 도우미 로그", text));
        Toast.makeText(this, "로그를 복사했습니다.", Toast.LENGTH_SHORT).show();
    }

    private void shareDiagnosticZip() {
        try {
            File zip = DiagnosticManager.buildZip(this);
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", zip);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("application/zip");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_SUBJECT, "알리 반품 도우미 진단파일");
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "진단파일 보내기"));
        } catch (Exception e) {
            Toast.makeText(this, "진단 ZIP 생성 실패: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void startAutomation(String mode) {
        savePcSettings(false);
        File session = DiagnosticManager.startNewSession(this);
        String status = mode.equals(MODE_CUSTOMS)
                ? "자동화 시작: 세관 보류"
                : "자동화 시작: 배송 실패·반송";
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean(KEY_ENABLED, true)
                .putBoolean(KEY_ARMED, true)
                .putString(KEY_MODE, mode)
                .putInt(KEY_STEP, 0)
                .putBoolean(KEY_AUTO_SUBMIT, autoSubmitCheck.isChecked())
                .putString(KEY_LAST_STATUS, status)
                .putString(KEY_LOG, "")
                .putString(KEY_PHASE, PHASE_NAVIGATE)
                .putInt(KEY_RETRY_TAP_COUNT, 0)
                .putLong(KEY_PHASE_STARTED_AT, System.currentTimeMillis())
                .apply();
        DiagnosticManager.append(this, status);
        DiagnosticManager.writeState(this, "automation_start");
        statusText.setText("상태: " + status);
        diagnosticPathText.setText("진단 저장 위치: " + session.getAbsolutePath());
        Toast.makeText(this, "실행 중 로그·화면·접근성 트리를 자동 저장합니다.", Toast.LENGTH_LONG).show();
        openAliExpress();
    }

    private void stopAutomation(String reason) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean(KEY_ARMED, false)
                .putString(KEY_LAST_STATUS, reason)
                .apply();
        DiagnosticManager.append(this, reason);
        DiagnosticManager.writeState(this, "stopped");
        statusText.setText("상태: " + reason);
        Toast.makeText(this, "자동화를 중지했습니다.", Toast.LENGTH_SHORT).show();
        PcDiagnosticUploader.autoUploadIfEnabled(this, reason);
    }

    private void openAliExpress() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.alibaba.aliexpresshd");
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(launch);
        } else {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("market://details?id=com.alibaba.aliexpresshd")));
            } catch (Exception e) {
                Toast.makeText(this, "알리익스프레스 앱을 찾지 못했습니다.", Toast.LENGTH_LONG).show();
            }
        }
    }
}
